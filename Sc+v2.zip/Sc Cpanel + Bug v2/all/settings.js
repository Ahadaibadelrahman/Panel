require("./module")

global.owner = "    62831116402410"
global.namabot = "AzzamStore"
global.namaCreator = "AzzamStore"
global.autoJoin = false
global.antilink = false
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.domain = 'https://panelku.digital-market.me' // Isi Domain Lu
global.apikey = 'ptla_Pzx5RohGPJMMQSYPhghaZET6tULCHpRvcAz3B2ftcrQ' // Isi Apikey Plta Lu
global.capikey = 'ptlc_L302cNGzHT1VNYGi57wi28PHP7ErsWRDiguqDFhhQMB' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
global.thumb = fs.readFileSync("./thumb.png")
global.audionya = fs.readFileSync("./all/sound.mp3")
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.packname = ""
global.author = "Sticker By RafatharOffcial"
global.jumlah = "5"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})